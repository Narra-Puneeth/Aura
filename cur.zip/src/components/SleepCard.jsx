import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import Card from './Card';

const SleepCard = ({ sleepData }) => {
  // Process sleep data for chart
  const getSleepChartData = () => {
    if (!sleepData || !sleepData.sleep) return [];
    
    return sleepData.sleep.map(sleep => ({
      date: sleep.dateOfSleep,
      deep: sleep.levels?.summary?.deep?.minutes || 0,
      light: sleep.levels?.summary?.light?.minutes || 0,
      rem: sleep.levels?.summary?.rem?.minutes || 0,
      wake: sleep.levels?.summary?.wake?.minutes || 0,
      total: sleep.minutesAsleep || 0
    }));
  };

  // Get sleep stats
  const getSleepStats = () => {
    if (!sleepData?.summary) return null;
    return {
      totalMinutes: sleepData.summary.totalMinutesAsleep || 0,
      efficiency: sleepData.sleep?.[0]?.efficiency || 0,
      deep: sleepData.sleep?.[0]?.levels?.summary?.deep?.minutes || 0,
      light: sleepData.sleep?.[0]?.levels?.summary?.light?.minutes || 0,
      rem: sleepData.sleep?.[0]?.levels?.summary?.rem?.minutes || 0,
      wake: sleepData.sleep?.[0]?.levels?.summary?.wake?.minutes || 0
    };
  };

  const chartData = getSleepChartData();
  const stats = getSleepStats();

  // Custom Tooltip
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-900 border border-gray-700 p-3 rounded-lg shadow-xl">
          <p className="text-white font-semibold mb-2">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {entry.value} min
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Sleep Chart */}
      <Card className="p-6">
        <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
          <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
          </svg>
          Sleep Stages
        </h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
              <XAxis 
                dataKey="date" 
                stroke="rgba(255, 255, 255, 0.5)"
                tick={{ fill: 'rgba(255, 255, 255, 0.7)' }}
              />
              <YAxis 
                stroke="rgba(255, 255, 255, 0.5)"
                tick={{ fill: 'rgba(255, 255, 255, 0.7)' }}
                label={{ value: 'Minutes', angle: -90, position: 'insideLeft', fill: 'rgba(255, 255, 255, 0.7)' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ color: '#fff' }} />
              <Bar dataKey="deep" stackId="a" fill="#8b5cf6" name="Deep" radius={[0, 0, 0, 0]} />
              <Bar dataKey="light" stackId="a" fill="#3b82f6" name="Light" radius={[0, 0, 0, 0]} />
              <Bar dataKey="rem" stackId="a" fill="#f59e0b" name="REM" radius={[0, 0, 0, 0]} />
              <Bar dataKey="wake" stackId="a" fill="#ef4444" name="Wake" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Sleep Summary */}
      {stats && (
        <Card className="p-6">
          <h3 className="text-xl font-bold text-white mb-4">Sleep Summary</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-purple-500/10 rounded-xl p-4 border border-purple-500/30">
              <div className="text-purple-400 text-sm mb-1">Deep Sleep</div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-white">{stats.deep}</span>
                <span className="text-gray-400 text-sm">min</span>
              </div>
              <div className="text-purple-300 text-xs mt-1">💤 Restorative</div>
            </div>

            <div className="bg-blue-500/10 rounded-xl p-4 border border-blue-500/30">
              <div className="text-blue-400 text-sm mb-1">Light Sleep</div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-white">{stats.light}</span>
                <span className="text-gray-400 text-sm">min</span>
              </div>
              <div className="text-blue-300 text-xs mt-1">😌 Restful</div>
            </div>

            <div className="bg-orange-500/10 rounded-xl p-4 border border-orange-500/30">
              <div className="text-orange-400 text-sm mb-1">REM Sleep</div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-white">{stats.rem}</span>
                <span className="text-gray-400 text-sm">min</span>
              </div>
              <div className="text-orange-300 text-xs mt-1">🧠 Dreaming</div>
            </div>

            <div className="bg-red-500/10 rounded-xl p-4 border border-red-500/30">
              <div className="text-red-400 text-sm mb-1">Awake</div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-white">{stats.wake}</span>
                <span className="text-gray-400 text-sm">min</span>
              </div>
              <div className="text-red-300 text-xs mt-1">👀 Restless</div>
            </div>
          </div>

          <div className="mt-6 flex items-center justify-between bg-gray-800/50 rounded-xl p-4 border border-gray-700">
            <div>
              <div className="text-gray-400 text-sm mb-1">Sleep Efficiency</div>
              <div className="text-3xl font-bold text-white">{stats.efficiency}%</div>
            </div>
            <div className="text-right">
              <div className="text-gray-400 text-sm mb-1">Total Sleep</div>
              <div className="text-3xl font-bold text-white">
                {Math.floor(stats.totalMinutes / 60)}h {stats.totalMinutes % 60}m
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

export default SleepCard;
