// Make sure this code runs in an async context
// (Node 18+ supports top-level await if "type": "module" is set in package.json)

const accessToken = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyM1RIOFEiLCJzdWIiOiI5R0MzUksiLCJpc3MiOiJGaXRiaXQiLCJ0eXAiOiJhY2Nlc3NfdG9rZW4iLCJzY29wZXMiOiJ3aHIgd251dCB3cHJvIHdzbGUgd2VjZyB3c29jIHdhY3Qgd294eSB3dGVtIHd3ZWkgd2lybiB3Y2Ygd3NldCB3bG9jIHdyZXMiLCJleHAiOjE3NjE0MzA3MDUsImlhdCI6MTc2MTQwMTkwNX0.1ObO8eQfGXnIKsuTa3-gXY7zogLslf6KMLlu7PcSgBs"; // Replace with your Fitbit OAuth 2.0 token
const date = "2025-10-25"; // Example date (yyyy-MM-dd)
const userId = "-"; // Use "-" for the current user

async function getSleepLogByDate() {
  try {
    const response = await fetch(
      `https://api.fitbit.com/1.2/user/${userId}/sleep/date/${date}.json`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${accessToken}`, // Required
          "Accept-Language": "en_US", // Optional
          Accept: "application/json"
        }
      }
    );

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(
        `Error ${response.status}: ${response.statusText}\n${errorData}`
      );
    }

    const data = await response.json();

    console.log("✅ Sleep Log Data:");
    console.log(JSON.stringify(data, null, 2));

    // Example: print total sleep minutes
    if (data.summary && data.summary.totalMinutesAsleep !== undefined) {
      console.log(`Total Minutes Asleep: ${data.summary.totalMinutesAsleep}`);
    }

  } catch (err) {
    console.error("❌ Failed to fetch sleep log:", err.message);
  }
}

getSleepLogByDate();
