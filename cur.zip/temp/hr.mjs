import fs from "fs";
// import fetch from "node-fetch";

const ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyM1RIOFEiLCJzdWIiOiI5R0MzUksiLCJpc3MiOiJGaXRiaXQiLCJ0eXAiOiJhY2Nlc3NfdG9rZW4iLCJzY29wZXMiOiJ3aHIgd251dCB3cHJvIHdzbGUgd2VjZyB3c29jIHdhY3Qgd294eSB3dGVtIHd3ZWkgd2lybiB3Y2Ygd3NldCB3bG9jIHdyZXMiLCJleHAiOjE3NjE0MzA3MDUsImlhdCI6MTc2MTQwMTkwNX0.1ObO8eQfGXnIKsuTa3-gXY7zogLslf6KMLlu7PcSgBs"; // Must include heartrate+intraday scopes
const DATE = "today"; // or "today"

const API_URL = `https://api.fitbit.com/1/user/-/activities/heart/date/${DATE}/1d/1min.json`;

async function fetchBPMData() {
  try {
    const response = await fetch(API_URL, {
      headers: {
        "accept": "application/json",
        "authorization": `Bearer ${ACCESS_TOKEN}`
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    fs.writeFileSync("bpm.json", JSON.stringify(data, null, 2));
    console.log("✅ BPM (intraday heart rate) data saved to bpm.json");
  } catch (err) {
    console.error("❌ Error fetching BPM data:", err.message);
  }
}

fetchBPMData();
