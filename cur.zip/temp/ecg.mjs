 // If using Node.js v18+, fetch is built-in, so you can remove this import
import fs from "fs";
// Replace this with your actual Fitbit access token
const ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyM1RIOFEiLCJzdWIiOiI5R0MzUksiLCJpc3MiOiJGaXRiaXQiLCJ0eXAiOiJhY2Nlc3NfdG9rZW4iLCJzY29wZXMiOiJ3aHIgd251dCB3cHJvIHdzbGUgd2VjZyB3c29jIHdhY3Qgd294eSB3dGVtIHd3ZWkgd2lybiB3Y2Ygd3NldCB3bG9jIHdyZXMiLCJleHAiOjE3NjE0MzA3MDUsImlhdCI6MTc2MTQwMTkwNX0.1ObO8eQfGXnIKsuTa3-gXY7zogLslf6KMLlu7PcSgBs";

async function fetchECGData() {
  const url = "https://api.fitbit.com/1/user/-/ecg/list.json?afterDate=2025-10-23&sort=asc&limit=10&offset=0";

  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "accept": "application/json",
        "authorization": `Bearer ${ACCESS_TOKEN}`
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();

    // Save the response data into ecg.json
    fs.writeFileSync("ecg.json", JSON.stringify(data, null, 2));
    console.log("✅ ECG data saved to ecg.json");
  } catch (error) {
    console.error("❌ Error fetching ECG data:", error.message);
  }
}

fetchECGData();
