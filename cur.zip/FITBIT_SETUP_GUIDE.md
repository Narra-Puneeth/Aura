# Fitbit API Setup Guide

## Your dashboard is now ready to use REAL Fitbit API data! 🎉

The application has been updated to make actual API calls to Fitbit instead of using mock data.

## Required: Access Token Setup

You need to provide a Fitbit access token for the API calls to work. Choose ONE of these options:

### Option 1: Using Browser localStorage (Quick Testing)

1. Open your browser's Developer Console (F12)
2. Go to the Console tab
3. Run this command (replace with your actual token):
```javascript
localStorage.setItem('fitbit_access_token', 'YOUR_FITBIT_ACCESS_TOKEN_HERE');
```
4. Refresh the dashboard page

### Option 2: Using Environment Variable (Recommended for Development)

1. Create a `.env` file in your project root (if it doesn't exist)
2. Add this line:
```
VITE_FITBIT_ACCESS_TOKEN=YOUR_FITBIT_ACCESS_TOKEN_HERE
```
3. Restart your development server

### Option 3: Using OAuth Flow (Best for Production)

The OAuth authentication service (`src/services/fitbitAuth.js`) is already created. To implement it:

1. Set up your Fitbit application at: https://dev.fitbit.com/apps
2. Get your Client ID and Client Secret
3. Update the auth service with your credentials
4. Add a login button to your dashboard that calls the OAuth flow

## How to Get a Fitbit Access Token

### Quick Method (For Testing):
1. Go to https://dev.fitbit.com/apps
2. Register/Login and create an OAuth 2.0 Application
3. Use the OAuth 2.0 tutorial page to generate a temporary token
4. Copy the access token

### Proper Method (OAuth 2.0):
1. Register your app at https://dev.fitbit.com/apps
2. Set the Callback URL (e.g., `http://localhost:5173/callback`)
3. Choose OAuth 2.0 Application Type: Personal
4. Implement the OAuth flow using `src/services/fitbitAuth.js`

## What's Changed

✅ **Real API Calls**: All API methods now make actual calls to Fitbit servers
✅ **Proper Authentication**: Bearer token authentication in all requests
✅ **Error Handling**: Comprehensive error handling with user-friendly messages
✅ **No Mock Data**: Removed all mock/sample data fallbacks
✅ **Token Management**: Automatic token retrieval from localStorage or environment

## API Endpoints Being Used

Your dashboard makes these Fitbit API calls:

### Heart Rate Data:
- `GET /1/user/-/activities/heart/date/{date}/1d/1min.json` (today's view)
- `GET /1/user/-/activities/heart/date/{startDate}/{endDate}.json` (week view)

### Sleep Data:
- `GET /1.2/user/-/sleep/date/{date}.json` (today's view)
- `GET /1.2/user/-/sleep/date/{startDate}/{endDate}.json` (week view)

### Activity Data:
- `GET /1/user/-/activities/date/{date}.json` (today's view)
- `GET /1/user/-/activities/{resource}/date/{startDate}/{endDate}.json` (week view)
  - Resources: steps, distance, calories, activityCalories

## Date Format

All dates are in **yyyy-mm-dd** format (e.g., 2025-01-28)

## Troubleshooting

### "No Fitbit access token found" error
- Make sure you've set up the access token using one of the options above
- Check browser console for detailed error messages

### "HTTP 401: Unauthorized" error
- Your access token is invalid or expired
- Get a new token from Fitbit Dev Portal
- Update localStorage or .env file with new token

### "HTTP 429: Rate Limit Exceeded" error
- Fitbit API has rate limits (150 requests/hour per user)
- Wait an hour or implement caching in the app

### No data showing up
- Check browser console for API errors
- Verify your Fitbit account has data for the selected dates
- Try switching between "Today" and "Week" views

## Testing

Once you've set up your access token:

1. Open the dashboard
2. You should see a loading spinner
3. Your actual Fitbit data will load:
   - Heart rate with intraday details
   - Sleep stages and efficiency
   - Steps, calories, and activity data
4. Toggle between "Today's Analysis" and "Current Week" views

## Need Help?

- Fitbit API Documentation: https://dev.fitbit.com/build/reference/web-api/
- OAuth 2.0 Guide: https://dev.fitbit.com/build/reference/web-api/developer-guide/authorization/
- Rate Limits: https://dev.fitbit.com/build/reference/web-api/developer-guide/application-design/

---

**Note**: The access tokens from Fitbit expire after 8 hours. For a production app, implement the OAuth flow with token refresh using the `fitbitAuth.js` service.
