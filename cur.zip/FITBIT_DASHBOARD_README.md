# Fitbit Dashboard Integration

This dashboard displays health and wellness data from Fitbit including heart rate, sleep, and activity metrics.

## Features

### 🔄 Time Range Toggle
- **Today's Analysis**: View detailed data for the current day
- **Current Week**: See trends over the past 7 days

### ❤️ Heart Rate Monitoring
- **Stats Card**: Shows resting heart rate in BPM
- **Chart**: Line/area chart showing heart rate throughout the day or week
- **Heart Rate Zones**: Displays time spent in each zone (Out of Range, Fat Burn, Cardio, Peak)

### 😴 Sleep Tracking
- **Stats Card**: Total sleep time and efficiency percentage
- **Chart**: Stacked bar chart showing sleep stages (Deep, Light, REM, Wake)
- **Sleep Summary**: Detailed breakdown of each sleep stage with emojis

### 🏃 Activity Tracking
- **Stats Cards**: Steps, Distance, Calories, Active Minutes
- **Chart**: 
  - Today: Horizontal bar chart of activity metrics
  - Week: Line chart showing trends over time

## API Integration

### Fitbit Web API Endpoints Used

#### Heart Rate
```javascript
// Single day with intraday data
GET /1/user/-/activities/heart/date/[date]/1d/1min.json

// Date range (daily summaries)
GET /1/user/-/activities/heart/date/[startDate]/[endDate].json
```

#### Sleep
```javascript
// Single day
GET /1.2/user/-/sleep/date/[date].json

// Date range
GET /1.2/user/-/sleep/date/[startDate]/[endDate].json
```

#### Activity
```javascript
// Single day summary
GET /1/user/-/activities/date/[date].json

// Time series (steps, distance, calories, etc.)
GET /1/user/-/activities/[resource]/date/[startDate]/[endDate].json
```

## File Structure

```
src/
├── services/
│   └── fitbitService.js       # API service with all Fitbit endpoints
└── pages/
    ├── Dashboard.jsx          # New Fitbit-integrated dashboard
    └── Dashboard.backup.jsx   # Original dashboard backup
```

## Setup Instructions

### 1. Get Fitbit Access Token

To use real Fitbit data, you need to:

1. Register an application at https://dev.fitbit.com/apps/new
2. Get your OAuth 2.0 credentials
3. Implement OAuth flow to get access token
4. Store the access token securely

### 2. Update Access Token

In `Dashboard.jsx`, replace the mock data usage:

```javascript
const [accessToken, setAccessToken] = useState(null);
```

With your actual token:

```javascript
const [accessToken, setAccessToken] = useState('YOUR_ACCESS_TOKEN_HERE');
```

### 3. Mock Data (Development)

The dashboard currently uses mock data from `fitbitService.js` when no access token is provided. This allows you to:
- Test the UI without API calls
- Develop without rate limits
- Demo the application

## Date Format

All dates use the format: `yyyy-mm-dd` (e.g., `2025-10-25`)

## Helper Functions

```javascript
formatDate(date)     // Converts Date object to yyyy-mm-dd
getToday()          // Returns today's date in yyyy-mm-dd
getDaysAgo(days)    // Returns date N days ago in yyyy-mm-dd
getWeekStart()      // Returns Monday of current week in yyyy-mm-dd
```

## API Response Structures

### Heart Rate Response
```json
{
  "activities-heart": [{
    "dateTime": "2025-10-25",
    "value": {
      "restingHeartRate": 76,
      "heartRateZones": [...]
    }
  }],
  "activities-heart-intraday": {
    "dataset": [
      {"time": "00:40:00", "value": 70},
      ...
    ]
  }
}
```

### Sleep Response
```json
{
  "sleep": [{
    "dateOfSleep": "2025-10-25",
    "duration": 25200000,
    "efficiency": 92,
    "minutesAsleep": 420,
    "levels": {
      "summary": {
        "deep": {"count": 3, "minutes": 90},
        "light": {"count": 10, "minutes": 240},
        "rem": {"count": 5, "minutes": 90},
        "wake": {"count": 8, "minutes": 60}
      }
    }
  }],
  "summary": {
    "totalMinutesAsleep": 420,
    "totalTimeInBed": 480
  }
}
```

### Activity Response
```json
{
  "summary": {
    "steps": 8543,
    "distance": 6.5,
    "floors": 12,
    "calories": 2145,
    "activeMinutes": 67
  }
}
```

## Charts Library

Uses **Recharts** for data visualization:
- `LineChart` / `AreaChart`: Heart rate trends
- `BarChart`: Sleep stages and activity metrics
- Responsive design with gradients and custom tooltips

## Styling

- **Gradient backgrounds**: Purple and pink theme (`--vyoma-purple`, `--vyoma-pink`)
- **Hover effects**: Cards scale and show gradient backgrounds
- **Dark theme**: Gray background with white text
- **Custom colors for data**:
  - Heart Rate: Red (#ef4444)
  - Sleep: Blue (#3b82f6)
  - Activity: Green (#10b981)
  - Calories: Orange (#f59e0b)

## Components Used

- `GridBackground`: Animated grid background
- `Navbar`: Top navigation (transparent)
- `Footer`: Bottom footer
- `Card`: Reusable card component with hover effects

## Future Enhancements

1. **OAuth Implementation**: Add proper authentication flow
2. **Date Picker**: Allow users to select custom date ranges
3. **Export Data**: Download reports as PDF/CSV
4. **Goals**: Set and track fitness goals
5. **Notifications**: Alert on low activity or poor sleep
6. **Comparison**: Compare current vs previous week/month
7. **Social**: Share achievements with friends

## Troubleshooting

### No data showing
- Check if `accessToken` is set
- Verify API responses in browser console
- Ensure mock data is properly loaded

### Charts not rendering
- Check if data is in correct format
- Verify Recharts is installed: `npm install recharts`
- Check browser console for errors

### API Rate Limits
- Fitbit API has rate limits (150 requests/hour)
- Implement caching for frequent requests
- Use mock data during development

## Resources

- [Fitbit Web API Documentation](https://dev.fitbit.com/build/reference/web-api/)
- [Recharts Documentation](https://recharts.org/)
- [OAuth 2.0 Guide](https://dev.fitbit.com/build/reference/web-api/developer-guide/authorization/)
